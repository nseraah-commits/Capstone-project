# Go Capstone Codebase

This is the "Minimal Working Example" for the Capstone Project. It is a simple HTTP server written in Go that returns a JSON response.

## Prerequisites
- [Go](https://go.dev/dl/) installed.

## How to Run

1.  Open your terminal in this directory.
2.  Run the application:
    
    go run main.go
 
3.  Open your browser or use curl to see the API in action:
  
   http://localhost:8080
 
    Or visit `http://localhost:8080` in Chrome/Safari.

## Expected Output
```json
{
  "message": "Hello from Go! This is your Capstone Project API.",
  "timestamp": "2024-12-16T13:00:00Z",
  "language": "Golang"
}
```
