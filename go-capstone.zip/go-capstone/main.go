package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"time"
)

// Response struct defines the JSON structure we will send back.
// In Go, struct fields must be capitalized to be exported (visible to JSON encoder).
type Response struct {
	Message   string    `json:"message"`
	Timestamp time.Time `json:"timestamp"`
	Language  string    `json:"language"`
}

// handler function processes the incoming HTTP request
func handler(w http.ResponseWriter, r *http.Request) {
	// Set the Content-Type header so the browser knows it's JSON
	w.Header().Set("Content-Type", "application/json")

	// Create a new instance of our Response struct
	data := Response{
		Message:   "Hello from Go! This is your Capstone Project API.",
		Timestamp: time.Now(),
		Language:  "Golang",
	}

	// Use json.NewEncoder to convert the struct to JSON and write it to the response
	err := json.NewEncoder(w).Encode(data)
	if err != nil {
		http.Error(w, "Failed to encode response", http.StatusInternalServerError)
		return
	}
}

func main() {
	// Register the handler function for the root path "/"
	http.HandleFunc("/", handler)

	// Define the port
	port := ":8080"
	fmt.Printf("Starting Server on http://localhost%s\n", port)
	fmt.Println("Press Ctrl+C to stop...")

	// Start the server
	// log.Fatal will print any error that occurs if ListenAndServe fails
	log.Fatal(http.ListenAndServe(port, nil))
}
